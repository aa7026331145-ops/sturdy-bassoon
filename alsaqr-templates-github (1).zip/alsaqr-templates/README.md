# الصقر لأنظمة المحاسبة — قوالب الفاتورة والإيصال (رسمية)

حزمة قوالب Word رسمية وجاهزة للطباعة والاستخدام داخل نظام **الصقر لأنظمة المحاسبة**.

## الملفات
- فاتورة A4 (ملونة): AlSaqr_Invoice_A4_Template_v3.docx
- فاتورة A4 (أحادي اللون للطباعة الاقتصادية): AlSaqr_Invoice_A4_Template_MONO_v3.docx
- إيصال POS 80mm (ملون): AlSaqr_POS_Receipt_80mm_Template_v3.docx
- إيصال POS 80mm (أحادي اللون للطباعة الاقتصادية): AlSaqr_POS_Receipt_80mm_Template_MONO_v3.docx

## الحقول الديناميكية
تُستبدل القيم بين {{ }} من قبل النظام أثناء الطباعة:
- {{CompanyAddress}}, {{CompanyPhone}}, {{CompanyVAT}}
- {{InvNo}}, {{Date}}, {{DateTime}}, {{StoreName}}, {{InvoiceType}}
- {{CustomerName}}, {{CustomerID}}, {{CustomerVAT}}, {{CustomerMobile}}
- {{BaseTotal}}, {{TaxTotal}}, {{NetTotal}}, {{Discount}}, {{Paid}}, {{Balance}}
- {{PayType}}, {{RefNo}}, {{Notes}}

## QR
تم تخصيص موضع واضح لرمز QR داخل القوالب.

## الترخيص
حر للاستخدام داخل مشروع الصقر لأنظمة المحاسبة.
